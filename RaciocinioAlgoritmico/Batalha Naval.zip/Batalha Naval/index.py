import pregame
import game

def logic():
    
    # Pre-Game
    pregame.posicionarBarcosBot()
    pregame.posicionarBarcosPlayer()

    # Game
    game()